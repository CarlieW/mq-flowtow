COMP249 FlowTow Assignment Starter Kit
--------------------------------------

This is the starter kit for the COMP249 Web Application assignment.  It contains
a copy of the assignment specifications in the 'static' directory.

The file main.py is the starting point for your project.  You may add new modules
if you wish, but main.py should always run your main application.

This initial package contains the functional and unit tests for Levels 1 and 2 of the
requirements.  

Further tests will be made available for Level 3 and 4.  

Addenda
-------

This section will list any changes made to this package.

1.0 30/3 Initial Release
1.1 31/3 Added additional functional test at level to so that comments are quoted in the HTML page