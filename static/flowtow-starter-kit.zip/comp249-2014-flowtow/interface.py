'''
Created on Mar 28, 2014

@author: steve
'''


def list_comments(db, filename):
    """Return a list of the comments stored for this image filename"""
    



def add_comment(db, filename, comment):
    """Add this comment to the database for this image filename"""
    
    
    
def list_images(db, n):
    """Return a list of tuples for the first 'n' images in 
    order of date.  Tuples should contain (filename, date, useremail, comments)."""
    

    
def add_image(db, filename, useremail):
    """Add this image to the database for the given user"""
    
